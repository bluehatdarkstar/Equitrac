#region script global variables

    #get the root directory to move files
    $rootFolder = "C:\Scripts\Equitrac\files\"
    $destinFolder = "C:\Scripts\Equitrac\moved\"
    $maxNumFiles = 1
    $i = 0
    $keyFile1 = '769784389b54ec04231fc1a7fe448cb3_81bacc29-5393-45aa-bc4d-64a41c646879'
    $keyFile2 = '6b45d390af5d329df6567fcb550d85a6_81bacc29-5393-45aa-bc4d-64a41c646879'
#endregion

#region select files and send to destination

    $destinFiles = Get-ChildItem -Path $rootFolder | % { $_.DirectoryName + "\$_" } | select -f $maxNumFiles
    $splitFiles = Split-Path $destinFiles -leaf
    
    foreach($split in $splitFiles) 
    {
        if (!($split -eq $keyFile1 -or $split -eq $keyFile2))
        {
        Move-Item $rootFolder$split -destination $destinFolder -Force
        Write-Host $split
        $i++
        }
    }

write-host $i
#endRegion